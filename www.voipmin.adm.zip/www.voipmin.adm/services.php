<?php
$servdns = 
if (!$servdns)){
echo "<p style='color:salmon;'>El servicio `named` de DNS, está parado o no se arrancó correctamente.</p>";
}else{
echo "<p style='color:lightgreen;'>El servicio `named` de DNS, está funcionando.</p>";
};
echo "Hola";
?>
