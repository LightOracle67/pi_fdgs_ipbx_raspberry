<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Inicio de Sesión para Administradores</title>
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<link rel="icon" href="img/favicon/favicon128.ico">

	</head>
	<body>
<div class="login">
			<img src="img/logo.png" width="60%" class="logo">
			<h1 style="margin: 0 auto">Inicio de Sesión</h1>
			<form action="auth.php" method="post" autocomplete="off">
				<label for="username">
					<i class="fas fa-user"></i>
				</label>
				<input type="text" name="usuario" placeholder="Usuario" id="Usuario" required>
				<label for="contrasena">
					<i class="fas fa-lock"></i>
				</label>
				<input type="password" name="contrasena" placeholder="Contraseña" id="contrasena" required>
				<input type="submit" value="Iniciar Sesión">
			</form>
		</div>
		<center>
		<div style="	width: 400px;
	margin: 0 auto;
	padding: 0 auto;
	display: flow-root;
	border-radius: 2em;
	background-color: #FF888A;">
		<?php
session_start();
$DATABASE_HOST = '127.0.0.1';
$DATABASE_USER = 'userread';
$DATABASE_PASS = 'LecturaUsuarios123*';
$DATABASE_NAME = 'voipmin';
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if ( mysqli_connect_errno() ) {
	exit('<h3>Falló la conexión al servidor: ' . mysqli_connect_error() . '</h3>');
}
if ( !isset($_POST['usuario'], $_POST['contrasena']) ) {
	exit('<h1>ERROR</h1><h3>Debes rellenar ambos campos. El usuario, la contraseña, o ambos, están vacíos.</h3>');
}
if ($stmt = $con->prepare('SELECT id, password FROM usuarios WHERE username = ?')) {
	$stmt->bind_param('s', $_POST['usuario']);
	$stmt->execute();
	$stmt->store_result();
if ($stmt->num_rows > 0) {
	$stmt->bind_result($id, $password);
	$stmt->fetch();
	if (password_verify($_POST['contrasena'], $password)) {
		session_regenerate_id();
		$_SESSION['loggedin'] = TRUE;
		$_SESSION['name'] = $_POST['usuario'];
		$_SESSION['id'] = $id;
		header('Location: home.php');
	} else {
		echo '<h1>ERROR</h1><h3>Usuario/Contraseña incorrectos.</h3>';
	}
} else {

	echo '<h1>ERROR</h1><h3>Usuario/Contraseña incorrectos.</h3>';
}

	$stmt->close();
}
			echo password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
?>
		</div>
							</center>
	</body>
</html>
