<?php
	$server_check_version = '1.0.4';
	$start_time = microtime(TRUE);
	$operating_system = PHP_OS_FAMILY;
	$cpu = shell_exec("cat /proc/cpuinfo | grep 'model name' | uniq");
	$cpuname = str_replace("model name",'',$cpu);
	if ($operating_system === 'Windows') {
		// Win CPU
		$wmi = new COM('WinMgmts:\\\\.');
		$cpus = $wmi->InstancesOf('Win32_Processor');
		$cpuload = 0;
		$cpu_count = 0;
		foreach ($cpus as $key => $cpu) {
			$cpuload += $cpu->LoadPercentage;
			$cpu_count++;
		}
		// WIN MEM
		$res = $wmi->ExecQuery('SELECT FreePhysicalMemory,FreeVirtualMemory,TotalSwapSpaceSize,TotalVirtualMemorySize,TotalVisibleMemorySize FROM Win32_OperatingSystem');
		$mem = $res->ItemIndex(0);
		$memtotal = round($mem->TotalVisibleMemorySize / 1000000,2);
		$memavailable = round($mem->FreePhysicalMemory / 1000000,2);
		$memused = round($memtotal-$memavailable,2);
		// WIN CONNECTIONS
		$connections = shell_exec('netstat -nt | findstr :80 | findstr ESTABLISHED | find /C /V ""'); 
		$totalconnections = shell_exec('netstat -nt | findstr :80 | find /C /V ""');
	} else {
		// Linux CPU
		$load = sys_getloadavg();
		$cpuload = $load[0];
		$cpu_count = shell_exec('nproc');
		// Linux MEM
		$free = shell_exec('free');
		$free = (string)trim($free);
		$free_arr = explode("\n", $free);
		$mem = explode(" ", $free_arr[1]);
		$mem = array_filter($mem, function($value) { return ($value !== null && $value !== false && $value !== ''); }); // removes nulls from array
		$mem = array_merge($mem); // puts arrays back to [0],[1],[2] after 
		$memtotal = round($mem[1] / 1000000,2);
		$memused = round($mem[2] / 1000000,2);
		$memfree = round($mem[3] / 1000000,2);
		$memshared = round($mem[4] / 1000000,2);
		$memcached = round($mem[5] / 1000000,2);
		$memavailable = round($mem[6] / 1000000,2);
		// Linux Connections
		$connections = `netstat -ntu | grep :80 | grep ESTABLISHED | grep -v LISTEN | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | grep -v 127.0.0.1 | wc -l`; 
		$totalconnections = `netstat -ntu | grep :80 | grep -v LISTEN | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | grep -v 127.0.0.1 | wc -l`; 
	}

	$memusage = round(($memavailable/$memtotal)*100);



	$phpload = round(memory_get_usage() / 1000000,2);

	$diskfree = round(disk_free_space(".") / 1000000000);
	$disktotal = round(disk_total_space(".") / 1000000000);
	$diskused = round($disktotal - $diskfree);

	$diskusage = round($diskused/$disktotal*100);
	$statestr = "";
	if ($memusage > 85 || $cpuload > 85 || $diskusage > 85) {
		$trafficlight = 'red';
		$statestr = 'CRÍTICO - Requiere atención inmediata';
	} elseif ($memusage > 50 || $cpuload > 50 || $diskusage > 50) {
		$trafficlight = 'orange';
		$statestr = 'MEDIO - Capacidad de procesamiento limitada';
	} else {
		$trafficlight = '#2F2';
		$statestr = 'BAJO - Capacidad de procesamiento completa';
	}

	$end_time = microtime(TRUE);
	$time_taken = $end_time - $start_time;
	$total_time = round($time_taken,4);

	// use servercheck.php?json=1
	if (isset($_GET['json'])) {
		echo '{"RAM":'.$memusage.',"CPU":'.$cpuload.',"DISCO":'.$diskusage.',"CONEXIONES":'.$totalconnections.'}';
		exit;
	}
?>
<!DOCTYPE html>
<html lang="es">
<head>
        <meta charset="UTF-8">
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<style>
#trafficlight {
                float: right;
                margin-top: 15px;
                width: 50px;
                height: 50px;
                border-radius: 50px;
                background: <?php echo $trafficlight; ?>;
                border: 3px solid #333;
        }
#statestrtext {
        color: <?php echo $trafficlight; ?>;
}

</style>
<body>
        <div id="container">
                <div class="content2" style="width: -webkit-fill-available">
                <div id="trafficlight" class="nodark"></div>
                <b><p>Nivel de Advertencia:</p><br><p id="statestrtext"><?php echo $statestr;?></p></b>
                </div>
                <hr>
                <div>
                <div class="content2">
                <h3><img src="https://png.vector.me/files/images/3/3/332672/internet_icon_preview" width="30px">CONEXIONES</h3>
                <p><span class="description"> Conexiones Establecidas: </span> <span class="result"><?php echo $connections; ?></span></p>
                <p><span class="description"> Conexiones Totales: </span> <span class="result"><?php echo $totalconnections; ?></span></p>
                <p><span class="description">💻 Dirección IP del Servidor: </span> <span class="result"><?php echo $_SERVER['SERVER_ADDR']; ?></span></p>
                </div>
                <div class="content2">
                <h3><img src="https://cdn.pixabay.com/photo/2013/07/12/17/56/cpu-152656_960_720.png" width="30px">CPU</h3>
                <p><span class="description">️ Modelo de CPU</span> <span class="result big"><?php echo $cpuname ?></span></p>
                <p><span class="description">️ Uso de Procesador: </span> <span class="result big"><?php echo $cpuload; ?>%</span></p>
                <p><span class="description">️ Núcleos de CPU:</span> <span class="result"><?php echo $cpu_count; ?></span></p>
                </div>
                </div>
                <div>
                <div class="content2">
                <h3><img src="https://infos-geek.com/wp-content/uploads/2021/06/verifier-et-nettoyer-ram-9.png?ezimgfmt=rs:256x256" width="30px"/>MEMORIA</h3>
                <p><span class="description">️ Uso de Memoria:</span> <span class="result big"><?php echo $memusage; ?>%</span></p>
                <p><span class="description">️ Memoria Total:</span> <span class="result"><?php echo $memtotal; ?> GB</span></p>
                <p><span class="description">️ Memoria Usada:</span> <span class="result"><?php echo $memused; ?> GB</span></p>
                <p><span class="description">️ Memoria Disponible:</span> <span class="result"><?php echo $memavailable; ?> GB</span>
                </div>
                <div class="content2">
                <h3><img src="https://cdn-icons-png.flaticon.com/512/707/707377.png" width="30px">ALMACENAMIENTO</h3>
                <p><span class="description"> Uso de Disco: </span> <span class="result"><?php echo $diskusage; ?>%</span></p>
                <p><span class="description"> Almacenamiento Libre:</span> <span class="result"><?php echo $diskfree; ?> GB</span>
                <p><span class="description"> Almacenamiento Usado:</span> <span class="result"><?php echo $diskused; ?> GB</span>
                <p><span class="description"> Almacenamiento Total:</span> <span class="result"><?php echo $disktotal; ?> GB</span>
                </div>
                </div>
                <div id="details">
                        <h3>DETALLES</h3>
                        <hr>
                        <p><span class="description"><img src="https://cdn.freebiesupply.com/logos/large/2x/php-1-logo-png-transparent.png" width="25px"><span class="result"> Versión de PHP: <?php echo phpversion(); ?></span></p>
                        <p><span class="description">️<img src="https://cdn.pixabay.com/photo/2013/07/12/17/56/cpu-152656_960_720.png" width="20px"><span class="result"> Consumo de Recursos por PHP: <?php echo $phpload;?>GB</span></p>
                        <p><span class="description">⏱️ Tiempo de Carga: </span> <span class="result"><?php echo $total_time; ?> segs. </span></p>
                </div>
        </div>
</body>
</html>
