<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Panel de Control</title>
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
				<link rel="icon" href="img/favicon/favicon128.ico">
		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
	</head>
	<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>
	<body class="loggedin">
		<nav class="navtop">
				<div class="navtopprimary">
				<div class="navtopsecondary">
				<center>
				<a href="home.php"><img src="img/logo.png" width="35%"></img></a></center>
				</div>
				<div class="navtopsecondary">
					<i class="fas fa-user-circle">
						<p style="display: inline-flex"><?=$_SESSION['name']?></p>
					</i>
				</div>
				<div class="navtopsecondary">
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Cerrar Sesión</a>
			</div>
</div>
		</nav>

		<div class="content">
<p>Servidor : <?php echo  php_uname();?></p>
			<div>
				<?php
		echo "<div><h2>Estado del Servidor</h2>";
		include "sys.php";
		echo"</div>";
		echo "<div><h2>Servicios</h2>";
					?>
<center>
<div style="display:block width:inherit">
<div class="content2">
<h2>ApacheV2 - Servidor Web</h2><hr>
<div style="float:left; text-align:left;">
<p>Estado: <?php include "services/apachestate.php"?></p>
</div>
<a href="services/apacheconf.php">Configuración</a>
<div style="width:100%; display:flex; justify-content:space-between;">
<input type="button" onclick="startadds()" value="Iniciar Servicio">
<input type="button" onclick="stopadds();" value="Parar Servicio">
<input type="button" onclick="reloadadds();" value="Reiniciar Servicio">
</div>
</div>

<div class="content2">
<h2>MySQL Server - Servidor de Base de Datos</h2><hr>
<div style="float:left; text-align:left;">
<p>Estado: <?php include "services/mysqlstate.php"?></p>
</div>
<a href="services/sqlconf.php">Configuración</a>
<div style="width:100%; display:flex; justify-content:space-between;">
<input type="button" onclick="startadds()" value="Iniciar Servicio">
<input type="button" onclick="stopadds();" value="Parar Servicio">
<input type="button" onclick="reloadadds();" value="Reiniciar Servicio">
</div>
</div>

<div style="display:block width:inherit">
<div class="content2">
<h2>BIND - Servidor DNS</h2><hr>
<div style="float:left; text-align:left;">
<p>Estado: <?php include "services/bindstate.php"?></p>
</div>
<a href="services/bindconf.php">Configuración</a>
<div style="width:100%; display:flex; justify-content:space-between;">
<input type="button" onclick="startdns()" value="Iniciar Servicio">
<input type="button" onclick="stopdns();" value="Parar Servicio">
<input type="button" onclick="reloaddns();" value="Reiniciar Servicio">
</div>
</div>
<div class="content2">
<h2>ISC DHCP SERVER - Servidor DHCP</h2><hr>
<div style="float:left; text-align:left;">
<p>Estado: <?php include "services/iscdhcpsrvstate.php";?></p>
</div>
<a href="services/iscdhcpsrvconf.php">Configuración</a>
<div style="width:100%; display:flex; justify-content:space-between;">
<input type="button" onclick="startdhcp()" value="Iniciar Servicio">
<input type="button" onclick="stopdhcp();" value="Parar Servicio">
<input type="button" onclick="reloaddhcp();" value="Reiniciar Servicio">
</div>
</div>
<div class="content2">
<h2>ACTIVE DIRECTORY</h2><hr>
<div style="float:left; text-align:left;">
<p>Estado: <?php include "services/addsstate.php";?></p></div>

<a href="services/addsconf.php">Configuración</a>
<div style="width:100%; display:flex; justify-content:space-between;">
<input type="button" onclick="startadds()" value="Iniciar Servicio">
<input type="button" onclick="stopadds();" value="Parar Servicio">
<input type="button" onclick="reloadadds();" value="Reiniciar Servicio">
</div>
</div>
<div class="content2">
<h2>OpenSSH - Servidor SSH</h2><hr>
<div style="float:left; text-align:left;">
<p>Estado: <?php include "services/opensshstate.php";?></p></div>
<a href="services/opensshconf.php">Configuración</a>
<div style="width:100%; display:flex; justify-content:space-between;">
<input type="button" onclick="startssh()" value="Iniciar Servicio">
<input type="button" onclick="stopssh();" value="Parar Servicio">
<input type="button" onclick="reloadssh();" value="Reiniciar Servicio">
</div>

</div>
</div>
</div>
</center>

			</div>

		</div>
	</body>
</html>
