<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Panel de Control</title>
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
				<link rel="icon" href="img/favicon/favicon128.ico">

	</head>
	<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: index.html');
	exit;
}
?>
	<body class="loggedin">
<center>
		<nav class="navtop">
			<div>
				<div>
				<a href="#"><img src="img/logo.png" class="logo"></img></a>
				</div>
				<div style="width: 400px; margin:0 auto; font-size: 2em">
					<i class="fas fa-user-circle">
						<p style="display: inline-flex"><?=$_SESSION['name']?></p>
					</i>
				</div>
				<div>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Cerrar Sesión</a>
			</div>
			</div>
		</nav>
</center>

		<div class="content">
<p>Servidor : <?php echo  php_uname();?></p>
			<div>
				<?php
		echo "<div><h2>Estado del Servidor</h2>";
		include "sys.php";
		echo"</div>";
		echo "<div><h2>Servicios</h2></div>";
					?>
<center>
<div style="display:block width:inherit">
<div class="content2">
<h2>ApacheV2 - Servidor Web</h2><hr>
<p>Estado: <?php include "apachestate.php"?></p>
<a href="apacheconf.php">Configuración</a>
</div>
<div class="content2">
<h2>MySQL Server - Servidor de Base de Datos</h2><hr>
<p>Estado: <?php include "mysqlstate.php"?></p>
<a href="sqlconf.php">Configuración</a>
</div>
</div>
<div style="display:block width:inherit">
<div class="content2">
<h2>BIND - Servidor DNS</h2><hr>
<p>Estado: <?php include "bindstate.php"?></p>
<a href="bindconf.php">Configuración</a>
</div>
<div class="content2">
<h2>ISC DHCP SERVER - Servidor DHCP</h2><hr>
<p>Estado: <?php include "iscdhcpsrvstate.php"?></p>
<a href="iscdhcpsrvconf.php">Configuración</a>
</div>
</div>

</center>

			</div>

		</div>
	</body>
</html>
